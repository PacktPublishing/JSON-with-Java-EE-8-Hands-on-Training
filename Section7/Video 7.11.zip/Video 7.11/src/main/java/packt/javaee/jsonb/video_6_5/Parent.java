package packt.javaee.jsonb.video_6_5;

public class Parent {
    public String parent2 = "Parent_2";
    public String parent1 = "Parent_1";
}
