package packt.javaee.jsonb.video_7_10;

public class Car {
    // In Miles
    private Double distance;

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }
}
