package packt.javaee.jsonb.video_7_2;

public class Customer {

    private String customerName = "Jason Voorhees";

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
