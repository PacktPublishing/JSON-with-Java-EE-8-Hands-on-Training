package packt.javaee.jsonb.names;

public class Customer {

    private String customerName = "Jason Voorhees";

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
