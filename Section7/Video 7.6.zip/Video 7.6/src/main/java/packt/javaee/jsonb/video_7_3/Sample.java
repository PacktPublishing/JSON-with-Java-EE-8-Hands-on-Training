package packt.javaee.jsonb.video_7_3;

public class Sample {
    public String sample2 = "Sample_2";
    public String sample1 = "Sample_1";
    public String sample3 = "Sample_3";
}
