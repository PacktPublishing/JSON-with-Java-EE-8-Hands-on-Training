package packt.javaee.jsonb.order;

public class Child extends Parent {
    public String child2 = "Child_2";
    public String child1 = "Child_1";
}
