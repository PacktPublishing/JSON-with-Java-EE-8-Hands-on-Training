package packt.javaee.jsonb.order;

public class Parent {
    public String parent2 = "Parent_2";
    public String parent1 = "Parent_1";
}
