package packt.javaee.jsonb.video_7_4;

public class Nillable1 {

    public String nullField = null;

    public String anotherNullField = null;

    public String notNullField = "Not null";
}
