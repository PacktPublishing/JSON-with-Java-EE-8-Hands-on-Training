package packt.javaee.jsonb.video_7_7;

import java.util.Date;

public class DateFormatSample1 {

    public Date date = new Date();

    public Double number = 3.1415926;
}
