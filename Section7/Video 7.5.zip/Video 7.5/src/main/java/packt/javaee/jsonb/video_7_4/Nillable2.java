package packt.javaee.jsonb.video_7_4;

import javax.json.bind.annotation.JsonbProperty;

public class Nillable2 {
    @JsonbProperty(nillable = true)
    public String nullField = null;

    public String anotherNullField = null;

    public String notNullField = "Not null";
}
