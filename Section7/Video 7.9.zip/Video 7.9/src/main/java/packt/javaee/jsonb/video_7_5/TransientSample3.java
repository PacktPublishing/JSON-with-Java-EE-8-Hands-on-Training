package packt.javaee.jsonb.video_7_5;

import javax.json.bind.annotation.JsonbTransient;

public class TransientSample3 {

    public transient String transientField = "Serialzed?";

    private String field = "Serialized!";

    @JsonbTransient
    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    @Override
    public String toString() {
        return "TransientSample1{" +
                "transientField='" + transientField + '\'' +
                ", field='" + field + '\'' +
                '}';
    }
}
