package packt.javaee.jsonb.jaxrs;

import javax.json.stream.JsonGenerator;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Simple JAX-RS application demonstrating integration with JSON-P.
 */
@ApplicationPath("/")
public class App extends Application {

    public Set<Class<?>> getClasses() {
        Set<Class<?>> set = new HashSet<>();
        set.add(JasonsResource.class);
        return set;
    }

    @Override
    public Map<String, Object> getProperties() {
        return new HashMap<String, Object>() {{ put(JsonGenerator.PRETTY_PRINTING, true); }};
    }
}
