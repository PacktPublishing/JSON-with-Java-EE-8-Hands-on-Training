package packt.javaee.jsonb.jaxrs;

import packt.javaee.jsonb.jaxrs.model.Jason;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

@Path("/jasons")
public class JasonsResource {
    private static List<Jason> jasons = new ArrayList<>();

    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Jason> doList() {
        return jasons;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Jason doGet(@QueryParam("id") int id) {
        for (Jason jason : jasons) {
            if (jason.getId() == id) {
                return jason;
            }
        }
        return null;
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public void doPost(Jason jason) {
        for (int i=0; i<jasons.size(); i++) {
            if (jasons.get(i).getId() == jason.getId()) {
                jasons.set(i, jason);
                return;
            }
        }
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public List<Jason> doPut(Jason jason) {
        jasons.add(jason);
        return jasons;
    }

    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public List<Jason> doDelete(@QueryParam("id") int id) {
        for (Jason jason : jasons) {
            if (jason.getId() == id) {
                jasons.remove(jason);
                break;
            }
        }
        return jasons;
    }
}
