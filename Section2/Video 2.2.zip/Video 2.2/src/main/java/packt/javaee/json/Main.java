package packt.javaee.json;

import java.util.Scanner;

/**
 * JSON with Java EE: Hands on Training.
 *
 * @author Dmitry Kornilov
 */
public class Main {

    public static void main(String[] args) {
        new Main().start();
    }

    private void start() {
        while (true) {
            printOptions();

            Scanner scanner = new Scanner(System.in);
            switch (scanner.nextLine()) {
                case "q":
                case "Q":
                    return;
                case "1":
                    jsonParserScenario();
            }
        }
    }

    private void printOptions() {
        System.out.println();
        System.out.println("----------------------- JSON with Java EE: Hand on Training -----------------------");
        System.out.println();
        System.out.println("Choose a scenario to run or press 'Q' to exit:");
        System.out.println();
        System.out.println("1. JSON parser");

        System.out.println();
        System.out.println("-----------------------------------------------------------------------------------");
    }

    /**
     * JsonParser demo.
     */
    private void jsonParserScenario() {

    }
}