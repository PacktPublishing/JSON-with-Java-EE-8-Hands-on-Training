package packt.javaee.json;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParserFactory;
import java.util.Scanner;

/**
 * JSON with Java EE: Hands on Training.
 *
 * @author Dmitry Kornilov
 */
public class Main {

    public static void main(String[] args) {
        new Main().start();
    }

    private void start() {
        while (true) {
            printOptions();

            Scanner scanner = new Scanner(System.in);
            switch (scanner.nextLine()) {
                case "q":
                case "Q":
                    return;
                case "1":
                    jsonParserScenario();
            }
        }
    }

    private void printOptions() {
        System.out.println();
        System.out.println("----------------------- JSON with Java EE: Hand on Training -----------------------");
        System.out.println();
        System.out.println("Choose a scenario to run or press 'Q' to exit:");
        System.out.println();
        System.out.println("1. JSON parser");

        System.out.println();
        System.out.println("-----------------------------------------------------------------------------------");
    }

    /**
     * Scenario 1: Using JsonParser (Video 2.3).
     *
     * Challenges:
     *
     * 1. Parse document and list all JSON-P events
     * 2. List all keys corresponding to events
     * 3. List all values
     */
    private void jsonParserScenario() {
        JsonParser parser = Json.createParser(Main.class.getResourceAsStream("/jasons.json"));

        //JsonParserFactory jsonParserFactory = Json.createParserFactory(null);
        //JsonParser parser = jsonParserFactory.createParser(Main.class.getResourceAsStream("/jasons.json"));

        while (parser.hasNext()) {
            JsonParser.Event event = parser.next();
            System.out.print(event.toString());

            switch (event) {
                case KEY_NAME:
                case VALUE_STRING:
                case VALUE_NUMBER:
                    System.out.print(": " + parser.getString());
                    break;
                case VALUE_NULL:
                    System.out.print(": null");
                    break;
                case VALUE_TRUE:
                    System.out.print(": true");
                    break;
                case VALUE_FALSE:
                    System.out.print(": false");
            }

            System.out.println();
        }
    }
}