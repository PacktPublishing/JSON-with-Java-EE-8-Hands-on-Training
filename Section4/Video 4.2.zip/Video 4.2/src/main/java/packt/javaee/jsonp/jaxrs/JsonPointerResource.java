package packt.javaee.jsonp.jaxrs;

import javax.json.Json;
import javax.json.JsonPointer;
import javax.json.JsonValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/pointer")
public class JsonPointerResource extends BaseResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public JsonValue doGet(@QueryParam("p") String p) {
        JsonPointer pointer = Json.createPointer(p);
        return pointer.getValue(getData());
    }
}