package packt.javaee.jsonp.jaxrs;

import javax.json.Json;
import javax.json.JsonArray;

public class BaseResource {
    private static JsonArray data = null;

    protected JsonArray getData() {
        if (data == null) {
            data = Json.createReader(JsonPatchResource.class.getResourceAsStream("/jasons.json")).readArray();
        }
        return data;
    }

    protected void setData(JsonArray data) {
        this.data = data;
    }
}
