package packt.javaee.jsonp.jaxrs;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonPatch;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/patch")
public class JsonPatchResource extends BaseResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public JsonArray doGet() {
        return getData();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public JsonArray doPost(JsonArray data) {
        setData(data);
        return getData();
    }

    @PATCH
    @Consumes(MediaType.APPLICATION_JSON)
    public JsonArray doPatch(JsonArray patch) {
        JsonPatch p = Json.createPatch(patch);
        setData(p.apply(getData()));
        return getData();
    }
}
