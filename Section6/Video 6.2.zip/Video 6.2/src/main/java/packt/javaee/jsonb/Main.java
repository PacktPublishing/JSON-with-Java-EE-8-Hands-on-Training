package packt.javaee.jsonb;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import java.math.BigDecimal;
import java.util.Optional;
import java.util.Scanner;

/**
 * JSON with Java EE: Hands on Training.
 *
 * @author Dmitry Kornilov
 */
public class Main {

    public static void main(String[] args) {
        new Main().start();
    }

    private void start() {
        while (true) {
            printOptions();

            Scanner scanner = new Scanner(System.in);
            switch (scanner.nextLine()) {
                case "q":
                case "Q":
                    return;
                case "1":
                    basicTypesScenario();
            }
        }
    }

    private void printOptions() {
        System.out.println();
        System.out.println("JSON with Java EE: Hand on Training");
        System.out.println("===================================");
        System.out.println();
        System.out.println("Choose a scenario to run or press 'Q' to exit:");
        System.out.println();
        System.out.println("1. Mapping of basic and JDK specific types");

        System.out.println();
        System.out.println("===================================");
    }

    /**
     * Mapping of basic and JDK specific types.
     */
    private void basicTypesScenario() {
        Jsonb jsonb = JsonbBuilder.create();

        // String

        String str = "JSON Binding";
        System.out.println("String: " + str);

        String toJson = jsonb.toJson(str);
        System.out.println("toJson: " + toJson);

        String fromJson = jsonb.fromJson(toJson, String.class);
        System.out.println("fromJson: " + fromJson);

        // BigDecimal

        System.out.println();
        BigDecimal big = BigDecimal.TEN;
        System.out.println("BigDecimal: " + big);

        toJson = jsonb.toJson(big);
        System.out.println("toJson: " + toJson);

        BigDecimal bigFromJson = jsonb.fromJson(toJson, BigDecimal.class);
        System.out.println("fromJson: " + bigFromJson);
    }
}